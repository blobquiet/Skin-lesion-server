class BasicBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  downsample : NoneType
  stride : int
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_11.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_10.BatchNorm2d
  relu : __torch__.torch.nn.modules.activation.ReLU
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_11.Conv2d
  bn2 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_10.BatchNorm2d
  def forward(self: __torch__.torchvision.models.resnet.___torch_mangle_15.BasicBlock,
    x: Tensor) -> Tensor:
    conv1 = self.conv1
    out = (conv1).forward(x, )
    bn1 = self.bn1
    out0 = (bn1).forward(out, )
    relu = self.relu
    out1 = (relu).forward(out0, )
    conv2 = self.conv2
    out2 = (conv2).forward(out1, )
    bn2 = self.bn2
    out3 = (bn2).forward(out2, )
    out4 = torch.add_(out3, x)
    relu0 = self.relu
    return (relu0).forward(out4, )
